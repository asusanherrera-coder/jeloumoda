<h1>Hola {{ $user->nombre }}!</h1>
<p>Te has registrado correctamente en Jelou Moda.</p>
<p>Disfruta de tu experiencia de compra con nosotros.</p>